package ru.fishev.MyFirstTestAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstTestAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
