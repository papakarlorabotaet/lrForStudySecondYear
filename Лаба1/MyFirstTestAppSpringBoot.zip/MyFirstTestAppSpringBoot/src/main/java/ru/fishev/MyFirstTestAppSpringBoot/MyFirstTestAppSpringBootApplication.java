package ru.fishev.MyFirstTestAppSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstTestAppSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstTestAppSpringBootApplication.class, args);
	}

}
