package com.example.service_one.exception;

public class UnsupertCodeException extends Exception {


    public UnsupertCodeException(String s) {
        super(s);
    }
}
