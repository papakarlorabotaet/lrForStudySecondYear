package com.example.service_one;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class service_oneApplication {

    public static void main(String[] args) {
        SpringApplication.run(service_oneApplication.class, args);
    }

}
