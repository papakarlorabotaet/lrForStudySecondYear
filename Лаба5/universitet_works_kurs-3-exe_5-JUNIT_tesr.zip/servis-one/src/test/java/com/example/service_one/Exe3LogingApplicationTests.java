package com.example.service_one;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exe3LogingApplicationTests {

    @Test
    void contextLoads() {
    }

}
